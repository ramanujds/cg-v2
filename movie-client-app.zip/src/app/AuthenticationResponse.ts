export class AuthenticationResponse{
    token:string;
}