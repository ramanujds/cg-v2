import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private _http:HttpClient) { }

  deleteTheatre(id:number):Observable<any>{
      return this._http.delete("http://localhost:8000/users/admin/theater/theaterId/"+id);
  }

}
