import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserCredentials } from './UserCredentials';
import { Observable } from 'rxjs';
import { AuthenticationResponse } from './AuthenticationResponse';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private httpclient:HttpClient,private _router:Router) { }

  rootUrl="http://localhost:8000/login/public/authenticate";
  
  userLogin(credentials:UserCredentials):Observable<AuthenticationResponse>
  {
    return this.httpclient.post<AuthenticationResponse>(this.rootUrl,credentials);
  }

  userLogout(){
    sessionStorage.removeItem("auth-token");
    this._router.navigate(['/login']);
  }
}
