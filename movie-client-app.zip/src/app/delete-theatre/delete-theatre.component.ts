import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-delete-theatre',
  templateUrl: './delete-theatre.component.html',
  styleUrls: ['./delete-theatre.component.css']
})
export class DeleteTheatreComponent implements OnInit {

  constructor(private _admin:AdminService) { }

  ngOnInit(): void {
  }

  deleteTheatre(id:number){
    this._admin.deleteTheatre(id).subscribe(
      success=>console.log(success),
     failure=>console.log(failure)
    )
  }

}
