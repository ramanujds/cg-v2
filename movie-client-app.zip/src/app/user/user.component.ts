import { Component, OnInit } from '@angular/core';
import { Admin } from '../Admin';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(private userService:UserService) { }

  ngOnInit(): void {
  }

  // newUser(admin:Admin):Admin{
  //   this.userService.newUser(admin).subscribe(
  //     (response)=>
  //     {
  //       alert("user added "+response.adminId);
  //     },
  //     error=>
  //     {
  //       alert("could not add admin")
  //     }

  //   )
  //   return admin;
  // }
}
