import {Component, OnInit} from "@angular/core";
import { Book } from './book';

@Component({
    selector:'app-book',
    templateUrl:'./book.component.html',
    styleUrls:['./book.component.css']

})

export class BookComponent implements OnInit{
    
    books:Array<Book>=[];
    text="Show";
    visible=false;
    book=new Book();
    styleClass:string;
   
    ngOnInit(): void {
       
    }
    addBook(bookId,title,author,price){
       let book=new Book();
        book.bookId=bookId;
        book.title=title;
        book.author=author;
        book.price=price;
       this.books.push(book);
        
        
    }
    
}