export class Book{
    public bookId:number;
    public title:string;
    public author:string;
    public price:number;
}