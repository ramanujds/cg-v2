import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Admin } from './Admin';
import { Observable } from 'rxjs';
import { Customer } from './Customer';

@Injectable({
  providedIn: 'root'
})
export class UserService {

rootUrl="http://localhost:8000/users/users/public/"
  constructor(private httpClient:HttpClient) { }

  newAdmin(admin:Admin):Observable<Admin>
  {
    return this.httpClient.post<Admin>(this.rootUrl+"adminRegister",admin);
  }
  
  newCustomer(customer: Customer) :Observable<Customer>{
    return this.httpClient.post<Customer>(this.rootUrl+"customerRegister",customer);
     
  }
}
