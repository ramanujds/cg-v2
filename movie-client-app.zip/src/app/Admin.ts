export class Admin{
    adminId:number;
	adminName:string;
	adminPassword:string;
	dateOfBirth:Date;
	adminContact:string;
}