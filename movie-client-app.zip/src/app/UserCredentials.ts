export class UserCredentials{
    userId:number;
    password:string;
    usertype:string;
}