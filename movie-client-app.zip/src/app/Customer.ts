export class Customer{
    customerId:number;
	customerName:string;
	customerPassword:string;
	dateOfBirth:Date;
	myTickets:Array<Number>;
	customerContact:string;
}
