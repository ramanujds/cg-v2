import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user/user.component';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { CustomerComponent } from './customer/customer.component';
import { DeleteTheatreComponent } from './delete-theatre/delete-theatre.component';


const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'adminRegister',component:AdminComponent},
  {path:'customerRegister',component:CustomerComponent},
  {path:'register',component:UserComponent},
  {path:'delete-theatre', component:DeleteTheatreComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
