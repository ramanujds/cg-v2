import { Component, OnInit } from '@angular/core';
import { Customer } from '../Customer';
import { UserService } from '../user.service';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  constructor(private userService:UserService) { }

  ngOnInit(): void {
  }

  newUser(customer:Customer):Customer{
    this.userService.newCustomer(customer).subscribe(
      (response)=>
      { 
        alert("Customer added with id "+ response.customerId);
      },
      error=>
      {
        alert("could not add customer");
      }
    )
    return customer;
  }
}
