import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';
import { UserCredentials } from '../UserCredentials';
import { AuthenticationResponse } from '../AuthenticationResponse';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  token:AuthenticationResponse;

  constructor(private loginService:LoginService) { }

  ngOnInit(): void {
  }

  userLogin(credentials:UserCredentials):AuthenticationResponse
  {
    this.loginService.userLogin(credentials).subscribe(
      (response)=>{
       sessionStorage.setItem("auth-token",response.token);
      },
      error=>
      {
        alert("login failed")
      }
    )
    return this.token;
  }
}
