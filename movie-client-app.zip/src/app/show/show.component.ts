import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
  sum:number=0;
  num1:number=0;
  num2:number=0;
  flag=false;
  constructor() { }

  add():number{

      return this.num1+this.num2;
      
  }

  ngOnInit(): void {
  }


}
