export class Trainee{
    id:number;
    name:string;
    email:string;
}