import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddTraineeComponent } from './add-trainee/add-trainee.component';
import { ShowTraineesComponent } from './show-trainees/show-trainees.component';


const routes: Routes = [
  {
    path:'add-trainee', component:AddTraineeComponent
  },
  {
    path:'view-all', component:ShowTraineesComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
