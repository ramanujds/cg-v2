import { Injectable } from '@angular/core';
import { Trainee } from './Trainee';

@Injectable({
  providedIn: 'root'
})
export class TraineeDataService {

  traineeList:Array<Trainee>=[];
  constructor() { }
}
