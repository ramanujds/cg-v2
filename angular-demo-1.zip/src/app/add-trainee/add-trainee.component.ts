import { Component, OnInit } from '@angular/core';
import { Trainee } from '../Trainee';
import { TraineeDataService } from '../trainee-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-trainee',
  templateUrl: './add-trainee.component.html',
  styleUrls: ['./add-trainee.component.css']
})
export class AddTraineeComponent implements OnInit {

  constructor(private dataService:TraineeDataService,private router:Router) { }
  traineeList:Array<Trainee>=[];
 trainee:Trainee;
  ngOnInit(): void {
    this.trainee=new Trainee();
  }

  addTrainee(f:Trainee){
   
    this.trainee.name=f.name;
    this.trainee.id=f.id;
    this.trainee.email=f.email;
    this.dataService.traineeList.push(this.trainee);
    this.router.navigate(['/view-all']);
    console.log(f);
  }

}
