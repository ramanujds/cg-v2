import { Component, OnInit } from '@angular/core';
import { TraineeDataService } from '../trainee-data.service';

@Component({
  selector: 'app-show-trainees',
  templateUrl: './show-trainees.component.html',
  styleUrls: ['./show-trainees.component.css']
})
export class ShowTraineesComponent implements OnInit {

  constructor(public dataService:TraineeDataService) { }

  ngOnInit(): void {
  }

}
