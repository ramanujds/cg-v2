import { Component, OnInit } from '@angular/core';
import { Trainee } from '../Trainee';
import { TraineeApiService } from '../trainee-api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-trainee',
  templateUrl: './view-trainee.component.html',
  styleUrls: ['./view-trainee.component.css']
})
export class ViewTraineeComponent implements OnInit {

  trainees: Array<Trainee>;
  constructor(private apiService: TraineeApiService, private router:Router) { }

  ngOnInit(): void {
   this.loadRefreshData();
  }

  delete(id: number) {
    if(confirm("Sure to Delete?")){
    this.apiService.deleteTrainee(id).subscribe(
      response => {
        alert("Deleted Successfully");
        this.loadRefreshData();
      },
      error=>{
        alert("Deletion Failed");
      }
    )
    }
  }

  loadRefreshData(){
    this.apiService.getAllTrainees().subscribe(
      (response) => {
        this.trainees = response;
        console.log(this.trainees);
      },
      error => {
        alert("Error");
      }
    )
  }

  update(id:number){
      this.router.navigate(["/update/trainee-id/"+id]);
  }

}
