import { Component, OnInit } from '@angular/core';
import { Trainee } from '../Trainee';
import { TraineeApiService } from '../trainee-api.service';

@Component({
  selector: 'app-view-trainee',
  templateUrl: './view-trainee.component.html',
  styleUrls: ['./view-trainee.component.css']
})
export class ViewTraineeComponent implements OnInit {

  trainees:Array<Trainee>;
  constructor(private apiService:TraineeApiService) { }

  ngOnInit(): void {
    this.apiService.getAllTrainees().subscribe(
      (response)=>{
        this.trainees=response;
        console.log(this.trainees);
      },
      error=>{
        alert("Error");
      }
    )
  }

}
