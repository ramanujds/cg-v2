import { Component, OnInit } from '@angular/core';
import { TraineeApiService } from '../trainee-api.service';
import { ActivatedRoute } from '@angular/router';
import { Trainee } from '../Trainee';

@Component({
  selector: 'app-update-trainee',
  templateUrl: './update-trainee.component.html',
  styleUrls: ['./update-trainee.component.css']
})
export class UpdateTraineeComponent implements OnInit {

  constructor(private apiService:TraineeApiService,private route:ActivatedRoute) { }
  
  traineeId: number;
  traineeName: string;
  traineeDomain: string;
  traineeLocation: string;

  traineeDob: Date;

  ngOnInit(): void {
    this.route.params.subscribe(
      response=>{
        this.loadTrainee(response['id']);
      }
    )
  }

  loadTrainee(id:number){
      this.apiService.getTrainee(id).subscribe(
        response=>{
            this.traineeId=response.traineeId;
            this.traineeDob=response.traineeDob;
            this.traineeDomain=response.traineeDomain;
            this.traineeLocation=response.traineeLocation;
            this.traineeName=response.traineeName;
        }
      )
  }

  updateTrainee(trainee:Trainee){
    trainee.traineeId=this.traineeId;
    this.apiService.updateTrainee(trainee).subscribe(
      response=>{
        alert("Updated Successfully");
      },
      error=>{
        alert(error);
      }

      
    )
  }


}
