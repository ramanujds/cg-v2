import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Trainee } from './Trainee';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TraineeApiService {

  constructor(private httpClient:HttpClient) { }

  rootUrl="http://localhost:8888/api/trainees/"

  addTrainee(trainee:Trainee):Observable<Trainee>{
     return this.httpClient.post<Trainee>(this.rootUrl,trainee);
  }

  getTrainee(id:number):Observable<Trainee>{
    return this.httpClient.get<Trainee>(this.rootUrl+id);
  }


  getAllTrainees():Observable<Array<Trainee>>{
    return this.httpClient.get<Array<Trainee>>(this.rootUrl);
  }

  updateTrainee(trainee:Trainee):Observable<Trainee>{
    return this.httpClient.put<Trainee>(this.rootUrl,trainee);
  }





}
