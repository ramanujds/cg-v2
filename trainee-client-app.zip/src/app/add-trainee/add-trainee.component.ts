import { Component, OnInit } from '@angular/core';
import { Trainee } from '../Trainee';
import { TraineeApiService } from '../trainee-api.service';

@Component({
  selector: 'app-add-trainee',
  templateUrl: './add-trainee.component.html',
  styleUrls: ['./add-trainee.component.css']
})
export class AddTraineeComponent implements OnInit {

  constructor(private apiService:TraineeApiService) { }
  trainee:Trainee;
  ngOnInit(): void {
    this.trainee=new Trainee();
  }

 addTrainee(trainee:Trainee):Trainee{
   this.apiService.addTrainee(trainee).subscribe(
     (response)=>{
       alert("Trainee Created with ID : "+response.traineeId)
     },
     error=>{
       alert("Failed to add Trainee")
     }
   )



   return trainee;
 }

}
