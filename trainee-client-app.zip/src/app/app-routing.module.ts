import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddTraineeComponent } from './add-trainee/add-trainee.component';
import { ViewTraineeComponent } from './view-trainee/view-trainee.component';
import { UpdateTraineeComponent } from './update-trainee/update-trainee.component';


const routes: Routes = [
  {
    path:'add-trainee', component:AddTraineeComponent
  },
  {
    path:'view-all', component:ViewTraineeComponent
  },
  {
    path:'update/trainee-id/:id',component:UpdateTraineeComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
